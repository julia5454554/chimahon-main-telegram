import com.android.build.api.variant.FilterConfiguration
import mihon.buildlogic.Config
import mihon.buildlogic.getBuildTime
import mihon.buildlogic.getCommitCount
import mihon.buildlogic.getGitSha
import java.security.MessageDigest

plugins {
    id("mihon.android.application")
    id("mihon.android.application.compose")
    kotlin("plugin.parcelize")
    kotlin("plugin.serialization")
    alias(libs.plugins.aboutLibraries)
    id("com.github.ben-manes.versions")
}

val enableUpdater = Config.enableUpdater
val hasLocalOcr = file("../chimahon-local-ocr/build.gradle.kts").exists()
val releaseVersionName = providers.gradleProperty("releaseVersionName").orNull
val releaseVersionCode = providers.gradleProperty("releaseVersionCode").orNull?.toIntOrNull()
val includeLocalDictionaryHarness = providers.gradleProperty("includeLocalDictionaryHarness").orNull == "true"

// Keep diagnostic captures tied to the production renderer source set.
val rendererDigest = MessageDigest.getInstance("SHA-256")
val rendererSources = listOf(
    "app/src/main/java/eu/kanade/tachiyomi/ui/dictionary",
    "app/src/main/java/eu/kanade/presentation/theme",
    "chimahon/src/main/java/eu/kanade/tachiyomi/ui/dictionary", "gradle",
).flatMap { rootProject.fileTree(it).matching { include("**/*.kt", "**/*.toml") }.files } + listOf(
    rootProject.file("app/build.gradle.kts"), rootProject.file("chimahon/build.gradle.kts"),
    rootProject.file("chimahon/src/main/java/chimahon/HoshiDicts.kt"),
    rootProject.file("chimahon/src/main/java/chimahon/anki/AnkiProfile.kt"),
    rootProject.file("chimahon/src/main/java/chimahon/diagnostics/LookupProfiler.kt"),
    rootProject.file("chimahon/src/main/java/chimahon/audio/WordAudioDatabase.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/ui/reader/ReaderActivity.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/ui/reader/ReaderViewModel.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/ui/reader/viewer/OcrLookupPopup.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/ui/reader/loader/DirectoryPageLoader.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/ui/reader/loader/DownloadPageLoader.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/data/download/DownloadProvider.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/data/download/DownloadCache.kt"),
    rootProject.file("app/src/main/java/eu/kanade/tachiyomi/data/ocr/OcrCacheManager.kt"),
)
rendererSources.distinct().sortedBy { it.relativeTo(rootDir).invariantSeparatorsPath }.forEach {
    rendererDigest.update(it.relativeTo(rootDir).invariantSeparatorsPath.toByteArray())
    rendererDigest.update(0.toByte())
    rendererDigest.update(it.readBytes())
}
val rendererSourceHash = rendererDigest.digest().joinToString("") { "%02x".format(it) }

android {
    namespace = "eu.kanade.tachiyomi"

    defaultConfig {
        applicationId = "app.chimahon"

        versionCode = releaseVersionCode ?: 3
        versionName = releaseVersionName ?: "1.1.0"

        buildConfigField("String", "COMMIT_COUNT", "\"${getCommitCount()}\"")
        buildConfigField("String", "COMMIT_SHA", "\"${getGitSha()}\"")
        buildConfigField("String", "BUILD_TIME", "\"${getBuildTime(useLastCommitTime = false)}\"")
        buildConfigField("boolean", "UPDATER_ENABLED", enableUpdater.toString())
        buildConfigField("boolean", "HAS_LOCAL_OCR", hasLocalOcr.toString())
        buildConfigField("boolean", "NATIVE_RENDERER_DIAGNOSTICS", "false")
        buildConfigField("String", "DICTIONARY_RENDERER_SOURCE_SHA256", "\"$rendererSourceHash\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        val debug by getting {
            applicationIdSuffix = ".dev"
            versionNameSuffix = "-${getCommitCount()}"
            isPseudoLocalesEnabled = true
            // Keep debug BuildConfig stable between builds of the same commit.
            buildConfigField("String", "BUILD_TIME", "\"${getBuildTime(useLastCommitTime = true)}\"")
            buildConfigField("boolean", "UPDATER_ENABLED", "false")
            buildConfigField("boolean", "NATIVE_RENDERER_DIAGNOSTICS",
                providers.gradleProperty("chimahon.nativeDiagnostics").orNull.toBoolean().toString())
        }
        val release by getting {
            isMinifyEnabled = Config.enableCodeShrink
            isShrinkResources = Config.enableCodeShrink

            proguardFiles("proguard-android-optimize.txt", "proguard-rules.pro")

            buildConfigField("String", "BUILD_TIME", "\"${getBuildTime(useLastCommitTime = true)}\"")
            buildConfigField("boolean", "UPDATER_ENABLED", enableUpdater.toString())
        }

        val commonMatchingFallbacks = listOf(release.name)

        create("releaseTest") {
            initWith(release)

            applicationIdSuffix = ".rt"
            isMinifyEnabled = false
            isShrinkResources = false

            matchingFallbacks.addAll(commonMatchingFallbacks)
        }
        create("foss") {
            initWith(release)

            applicationIdSuffix = ".foss"

            matchingFallbacks.addAll(commonMatchingFallbacks)

            buildConfigField("boolean", "UPDATER_ENABLED", enableUpdater.toString())
        }
        create("preview") {
            initWith(release)

            applicationIdSuffix = ".beta"

            versionNameSuffix = debug.versionNameSuffix
            signingConfig = debug.signingConfig

            matchingFallbacks.addAll(commonMatchingFallbacks)

            buildConfigField("String", "BUILD_TIME", "\"${getBuildTime(useLastCommitTime = false)}\"")
            buildConfigField("boolean", "UPDATER_ENABLED", enableUpdater.toString())
        }
        create("benchmark") {
            initWith(release)

            isDebuggable = false
            isProfileable = true
            versionNameSuffix = "${debug.versionNameSuffix}-benchmark"
            applicationIdSuffix = ".benchmark"

            signingConfig = debug.signingConfig

            matchingFallbacks.addAll(commonMatchingFallbacks)

            buildConfigField("boolean", "UPDATER_ENABLED", enableUpdater.toString())
        }
    }

    sourceSets {
        getByName("preview").res.srcDirs("src/beta/res")
        getByName("benchmark").res.srcDirs("src/debug/res")
        if (includeLocalDictionaryHarness) {
            val harness = "../tools/dictionary-harness/app/src/debug"
            for (name in listOf("debug", "benchmark")) {
                getByName(name).apply {
                    java.srcDir("$harness/java")
                    assets.srcDir("$harness/assets")
                    manifest.srcFile("$harness/AndroidManifest.xml")
                }
            }
            getByName("test").java.srcDir("../tools/dictionary-harness/tests/app/java")
        }
    }

    splits {
        abi {
            isEnable = true
            isUniversalApk = true
            reset()
            include("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    packaging {
        jniLibs {
            keepDebugSymbols += listOf(
                "libandroidx.graphics.path",
                "libarchive-jni",
                "libconscrypt_jni",
                "libimagedecoder",
                "libquickjs",
                "libsqlite3x",
                "libmpv",
                "libavcodec",
                "libavformat",
                "libswscale",
                "libavutil",
                "libswresample",
                "libavfilter",
                "libass",
                "libdav1d",
                "libplacebo",
            )
                .map { "**/$it.so" }
        }
        resources {
            excludes += setOf(
                "kotlin-tooling-metadata.json",
                "LICENSE.txt",
                "META-INF/**/*.properties",
                "META-INF/**/LICENSE.txt",
                "META-INF/*.properties",
                "META-INF/*.version",
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/NOTICE",
                "META-INF/README.md",
                "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
            )
        }
        jniLibs {
            // LiteRT natives are downloaded at runtime, not bundled in the APK
            excludes += setOf(
                "**/libLiteRt.so",
                "**/libLiteRtClGlAccelerator.so",
                "**/liblitert_jni.so",
            )
        }
    }

    dependenciesInfo {
        includeInApk = Config.includeDependencyInfo
        includeInBundle = Config.includeDependencyInfo
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
        aidl = true

        // Disable some unused things
        renderScript = false
        shaders = false
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Packing the app's many class files costs more than recompiling a local debug edit.
// Keep incremental compilation; enable output caching in CI or with -PcacheDebugKotlin=true.
val cacheDebugKotlin = providers.gradleProperty("cacheDebugKotlin")
    .map { it.toBoolean() }
    .getOrElse(providers.environmentVariable("CI").isPresent)
tasks.matching { it.name == "compileDebugKotlin" }.configureEach {
    outputs.doNotCacheIf("Avoid expensive local debug Kotlin output caching") { !cacheDebugKotlin }
}

kotlin {
    compilerOptions {
        freeCompilerArgs.addAll(
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi",
            "-opt-in=androidx.compose.animation.graphics.ExperimentalAnimationGraphicsApi",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3ExpressiveApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=coil3.annotation.ExperimentalCoilApi",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            "-opt-in=kotlinx.coroutines.FlowPreview",
            "-opt-in=kotlinx.coroutines.InternalCoroutinesApi",
            "-opt-in=kotlinx.serialization.ExperimentalSerializationApi",
            "-Xannotation-default-target=param-property",
        )
    }
}

dependencies {
    implementation(projects.chimahon)
    // Telegram TDLib (Nuvem Telegram)
    implementation("com.github.tdlibx:td:1.8.6")

    if (hasLocalOcr) {
        implementation(project(":chimahon-local-ocr"))
    }

    implementation(projects.i18n)
    // ANK -->
    implementation(projects.i18nAnk)
    // ANK <--
    // KMK -->
    implementation(projects.i18nKmk)
    // KMK <--
    // SY -->
    implementation(projects.i18nSy)
    // SY <--
    implementation(projects.core.archive)
    implementation(projects.core.common)
    implementation(projects.coreMetadata)
    implementation(projects.sourceApi)
    implementation(projects.sourceLocal)
    implementation(projects.data)
    implementation(projects.domain)
    implementation(projects.presentationCore)
    implementation(projects.presentationWidget)
    // Compose
    implementation(compose.activity)
    implementation(compose.foundation)
    implementation(compose.material3.core)
    implementation(compose.material.icons)
    implementation(compose.animation)
    implementation(compose.animation.graphics)
    implementation(compose.glance)
    debugImplementation(compose.ui.tooling)
    implementation(compose.ui.tooling.preview)
    implementation(compose.ui.util)
    implementation(compose.constraintlayout)

    // Compose composition tracing: with runtime-tracing on the classpath the Compose compiler's
    // trace markers turn every recompose / measure / layout into a named slice, so a Perfetto
    // capture attributes frame time to individual composables instead of guessing. It embeds
    // unobfuscated tracing strings in the APK, so it is deliberately absent from release-facing
    // variants. tracing-perfetto is the SDK that lets a capture be enabled from adb rather than
    // only from Android Studio; -binary is the packaged Perfetto it falls back to.
    debugImplementation(compose.runtime.tracing)
    debugImplementation(androidx.tracing.perfetto)
    debugImplementation(androidx.tracing.perfetto.binary)
    // "benchmark" is a custom build type, so Gradle generates no typed accessor for it. Invoke the
    // configuration by name instead of relying on a benchmarkImplementation shorthand.
    "benchmarkImplementation"(compose.runtime.tracing)
    "benchmarkImplementation"(androidx.tracing.perfetto)
    "benchmarkImplementation"(androidx.tracing.perfetto.binary)

    implementation(androidx.interpolator)

    implementation(androidx.paging.runtime)
    implementation(androidx.paging.compose)

    implementation(libs.bundles.sqlite)


    implementation(kotlinx.reflect)
    implementation(kotlinx.immutables)

    implementation(platform(kotlinx.coroutines.bom))
    implementation(kotlinx.bundles.coroutines)

    // AndroidX libraries
    implementation(androidx.annotation)
    implementation(androidx.appcompat)
    implementation(androidx.biometricktx)
    implementation(androidx.constraintlayout)
    implementation(androidx.corektx)
    implementation(androidx.splashscreen)
    implementation(androidx.recyclerview)
    implementation(androidx.viewpager)
    implementation(androidx.profileinstaller)

    implementation(androidx.bundles.lifecycle)
    implementation(libs.datastore.preferences)

    // JS engine for LNReader plugins (Hayai reference), used directly by
    // chimahon.novel.plugin.runtime. Also backs the app.cash.quickjs API that manga
    // extensions link against, via the shim in core:common. This is the app's only
    // QuickJS native library; do not add com.github.zhanghai.quickjs-java, whose
    // libquickjs.so would collide with this one and break every extension JS call.
    implementation(libs.quickjs.kt)

    // Job scheduling
    implementation(androidx.workmanager)

    // RxJava
    implementation(libs.rxjava)

    // Networking
    implementation(libs.bundles.okhttp)
    implementation(libs.okio)
    implementation(libs.conscrypt.android) // TLS 1.3 support for Android < 10

    // Data serialization (JSON, protobuf, xml)
    implementation(kotlinx.bundles.serialization)

    // HTML parser
    implementation(libs.jsoup)

    // Disk
    implementation(libs.disklrucache)
    implementation(libs.unifile)

    // Preferences
    implementation(libs.preferencektx)

    // Dependency injection
    implementation(libs.injekt)

    // Image loading
    implementation(platform(libs.coil.bom))
    implementation(libs.bundles.coil)
    implementation(libs.subsamplingscaleimageview) {
        exclude(module = "image-decoder")
    }
    implementation(libs.image.decoder)

    // Image cropper
    implementation(libs.android.image.cropper)

    // EXIF orientation for camera captures (already shipped via :core:common)
    implementation(sylibs.exifinterface)

    // UI libraries
    implementation(libs.material)
    implementation(libs.flexible.adapter.core)
    implementation(libs.photoview)
    implementation(libs.directionalviewpager) {
        exclude(group = "androidx.viewpager", module = "viewpager")
    }
    implementation(libs.richeditor.compose)
    implementation(libs.aboutLibraries.compose)
    implementation(libs.bundles.voyager)
    implementation(libs.compose.materialmotion)
    implementation(libs.swipe)
    implementation(libs.compose.webview)
    implementation(libs.compose.grid)
    implementation(libs.reorderable)
    implementation(libs.bundles.markdown)
    implementation(libs.materialKolor)

    // KMK -->
    implementation(libs.palette.ktx)
    implementation(libs.haze)
    implementation(compose.colorpicker)
    implementation(projects.flagkit)
    // KMK <--

    // Logging
    implementation(libs.timber)
    implementation(libs.logcat)

    // Shizuku
    implementation(libs.bundles.shizuku)

    // String similarity
    implementation(libs.stringSimilarity)

    // Tests
    testImplementation(libs.bundles.test)
    testRuntimeOnly(libs.junit.platform.launcher)

    // For detecting memory leaks; see https://square.github.io/leakcanary/
    // debugImplementation(libs.leakcanary.android)
    implementation(libs.leakcanary.plumber)

    testImplementation(kotlinx.coroutines.test)

    // MPV player
    implementation(libs.aniyomi.mpv)
    implementation(libs.seeker)
    implementation(libs.ffmpeg.kit)
    implementation(libs.smart.exception.java)
    implementation(libs.mediasession)
    implementation(libs.truetypeparser)
    implementation(libs.torrentserver)
    implementation(libs.nanohttpd)
    implementation(libs.media.router)
    implementation(libs.cast.play.services)

    // SY -->
    // Better logging (EH)
    implementation(sylibs.xlog)

    // RatingBar (SY)
    implementation(sylibs.ratingbar)
    implementation(sylibs.composeRatingbar)

    // Google drive
    implementation(sylibs.google.api.services.drive)

    // ZXing Android Embedded
    implementation(sylibs.zxing.android.embedded)

    // NewPipe Extractor for YouTube stream resolution
    implementation(libs.newpipe.extractor)
}

androidComponents {
    // Debug outputs are limited to the ABIs named by -Pchimahon.debugAbi (default arm64-v8a).
    // A universal APK has no ABI filter at all, so it is only enabled when the property asks for it.
    val debugAbis = (findProperty("chimahon.debugAbi") as String? ?: "arm64-v8a")
        .split(",").map(String::trim).toSet()
    onVariants(selector().withBuildType("debug")) { variant ->
        variant.outputs.forEach { output ->
            output.enabled.set(
                output.filters.any {
                    it.filterType == FilterConfiguration.FilterType.ABI && it.identifier in debugAbis
                } || (output.filters.isEmpty() && debugAbis.contains("universal")),
            )
        }
    }
    onVariants(selector().withFlavor("default" to "standard")) {
        // Only excluding in standard flavor because this breaks
        // Layout Inspector's Compose tree
        it.packaging.resources.excludes.add("META-INF/*.version")
    }
}

buildscript {
    dependencies {
        classpath(kotlinx.gradle)
    }
}
